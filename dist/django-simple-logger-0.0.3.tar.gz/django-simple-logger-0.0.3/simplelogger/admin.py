from django.contrib import admin

from .models import LogRecord, ExceptionRecord



admin.site.register(LogRecord)
admin.site.register(ExceptionRecord)